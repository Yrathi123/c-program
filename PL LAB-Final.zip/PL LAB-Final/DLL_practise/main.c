#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    char data;
    struct Node *prev;
    struct Node *next;
}Node;
typedef struct Node node;
 node* Get_node();
 node* create_DLL();
 void display(node*);
 node* Insert_start(node*);
 void Insert_at_mid(node*);
 void Insert_at_end(node*);
 void Delete(node*);
 void Display_back(node*);


 node* Get_node()
 {
     node* temp;
     temp=(node*)malloc(sizeof(node));

     temp->next=NULL;
     temp->prev=NULL;
     return temp;
}

node* create_DLL()
{
    int i=0;
    char str[10];
   node *head,*p,*temp;
   head=p=NULL;
   printf("Enter the string:\n");
   scanf("%s",str);


  while(str[i]!='\0')
	{
		temp=Get_node();
		temp->data=str[i];
		if(head==NULL)
		{
			head=temp;
			p=temp;
		}
		else
		{
			p->next=temp;
			temp->prev=p;
			p=temp;
		}
		i++;
	}
    return head;

}
void display(node *head)
{
    int i=0;
    char str[10];
   if(head==NULL)
     {
    printf("list is EMPTY!\n");
    }
    while(head!=NULL)
    {
        printf("|%c|<->",head->data);
        head=head->next;

    }
}

node* Insert_start(node* head)
{

    char a;

    node *temp;
    printf("Enter the  character at beginning\n");
    scanf("%s",&a);

		temp=Get_node();
		temp->data=a;
    temp->next=head;
    head->prev=temp;
    head=temp;

    return head;

}

 void Insert_at_end(node* head)
 {
     char a;
     node *temp;

     printf("Enter the character (for end)\n");
     scanf("%s",&a);
      temp=Get_node();
     temp->data=a;
     while(head->next!=NULL)
     {
         head=head->next;
     }
     head->next=temp;
     temp->prev=head;

 }

 void Insert_at_mid(node* head)
 {
     char a;
     node *temp;
     int k,i=1;
     printf("Enter the character (for end)\n");
     scanf("%s",&a);
      temp=Get_node();
     temp->data=a;
     printf("Enter position at which you want to enter data\n");
     scanf("%d",&k);
     while(i<k)
     {
         head=head->next;
         i++;
     }
     temp->next=head->next;
     head->next->prev=temp;
     head->next=temp;
     temp->prev=head;
 }

 void Delete(node* head)
 {
     char a;
     node *q;
     int k,i=1;

     printf("Enter position at which you want to enter data\n");
     scanf("%d",&k);

     while(i<k)
     {
         q=head;
         head=head->next;
         i++;
     }
       if(head->next==NULL)
     {
         q->next=NULL;
     }
     else
     {
      q->next=head->next;
     head->next->prev=q;
     }
     free(head);
 }

void Display_back(node* head)
{
    while(head->next!=NULL)
    {
        head=head->next;
    }
    while(head!=NULL)
    {
        printf("|%c|<->",head->data);
        head=head->prev;
    }
}

int main()
{
     int i=0,ch;

    node *head;
     head=Get_node();
    head=create_DLL();
        do{
                printf("\n-------------------------------------------------------------------------------------------------------\n");
                printf("\nEnter your choice::\n");
        printf("1.Display node \n Insert node:\n\t 2.Insert at start \n\t 3.Insert in between \n\t 4.Insert at end\n");
        printf("5.Delete node \n 6.Display reverse \n 7. Exit\n");
        scanf("%d",&ch);
        switch(ch)
        {

        case 1:
            display(head);
            break;

        case 2:

                    head=Insert_start(head);
                    display(head);
                    break;
        case 3:
                    Insert_at_mid(head);
                     display(head);
                    break;

        case 4:
                    Insert_at_end(head);
                    display(head);
                    break;
        case 5:
                   Delete(head);
                   display(head);
                   break;
        case 6:
            printf("Display in reverse:\n");
            Display_back(head);
            break;

        default:
            printf("\nWrong option\n");
                    break;
            }
      }while(ch!=7);


    return 0;
}
