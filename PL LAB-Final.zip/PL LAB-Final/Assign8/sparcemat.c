/*
 ============================================================================
 Name        : sparsemat.c
 Author      : Rucha Shinde
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include<stdio.h>

typedef struct Sparse
{
 int row,col,val;
}sparse;

void Accept(int a[][6],int r,int c)
{
	int i,j;
	printf("Enter the number of elements in matrix:");
	for(i=0;i<r;i++)
	    for(j=0;j<c;j++)
		scanf("%d",&a[i][j]);
}//accept

void sparse_matrix(int a[][6],sparse s1[10],int r,int c)
{
	 int i,j,k=0;
 	 for(i=0;i<r;i++)
      	    for(j=0;j<c;j++)
	 	if(a[i][j]!=0)
	  	{
	    		s1[++k].row=i;
	    		s1[k].col=j;
	    		s1[k].val=a[i][j];
	  	}
 	s1[0].row=r;
 	s1[0].col=c;
 	s1[0].val=k;
}//sparse_mat

void sparse_put(sparse s1[10])
{
	int i;
	printf("\n %d \t %d \t %d ",s1[0].row,s1[0].col,s1[0].val);
	printf("\n------------------------------");
 	for(i=1;i<=s1[0].val;i++)
    		printf("\n %d \t %d \t %d ",s1[i].row,s1[i].col,s1[i].val);
}//sparse_put

void simple_transpose(sparse s1[10],sparse s2[10])
{
 	int k,i,j;
 	s2[0].row=s1[0].col;
 	s2[0].col=s1[0].row;
 	s2[0].val=s1[0].val;
 	k=1;
  	for(i=0;i<s1[0].col;i++)
   	  for(j=1;j<=s1[0].val;j++)
     		if(i==s1[j].col)
       		{
			s2[k].row=s1[j].col;
			s2[k].col=s1[j].row;
			s2[k].val=s1[j].val;
			k++;
       		}//if
}//trans

void fast_transpose(sparse s1[10],sparse s3[10])
{
 	int pos[6],term[6];
	int i,j;
 	for(i=0;i<6;i++)
	    	pos[i]=term[i]=0;
 	for(i=1;i<=s1[0].val;i++)
 	    	term[s1[i].col]++;
       	pos[0]=1;
  	for(i=1;i<=s1[0].col;i++)
     		pos[i]=pos[i-1]+term[i-1];
  	for(i=1;i<=s1[0].val;i++)
    	{
		j=pos[s1[i].col]++;
		s3[j].row=s1[i].col;
		s3[j].col=s1[i].row;
		s3[j].val=s1[i].val;
    	}//i
 	s3[0].row=s1[0].col;
	s3[0].col=s1[0].row;
 	s3[0].val=s1[0].val;
}//Fast_trans

void sparse_sum(sparse s1[10],sparse s2[10],sparse s3[10])
{
	int i,j,k,z;
	k=1;
  	for(i=1,j=1;(i<=s1[0].val)&&(j<=s2[0].val);)
    	{
		if(s1[i].row==s2[j].row)
		{
 	  		if(s1[i].col==s2[j].col)
	    		{
				z=s1[i].val+s2[j].val;
				if(z!=0)
				{
				s3[k].val=z;
				s3[k].row=s1[i].row;
				s3[k].col=s1[i].col;
                		i++;j++;k++;
				}
	    		}//if
			else if(s1[i].col>s2[j].col)
	   		{
				s3[k]=s2[j];
				j++;k++;
	   		}
			else
	    			s3[k++]=s1[i++];
		 }//main if
	//If row dosen't match then
         	else if(s1[i].row>s2[j].row)
	   		s3[k++]=s2[j++];
	 	else
	    		s3[k++]=s1[i++];
      	}//for
	while(j<=s2[0].val)
    	{
    		s3[k++]=s2[j++];
    	}//while
    	while(i<=s1[0].val)
    	{
    		s3[k++]=s1[i++];
    	}//while
 	s3[0].row=s1[0].row;
	s3[0].col=s1[0].col;
 	s3[0].val=--k;
}//function

void main()
{
	sparse s1[10],s2[10],s3[10],s4[10],s5[10];
	int a1[6][6],a2[6][6];
	int r1,r2,c1,c2,ch,ans;
 	printf("\n Enter Number of the Row and column of matrix 1:");
 	scanf("%d%d",&r1,&c1);
 	Accept(a1,r1,c1);
 	sparse_matrix(a1,s1,r1,c1);
	sparse_put(s1);

	printf("\nEnter Number of the Row and column of matrix 2:");
 	scanf("%d%d",&r2,&c2);
 	Accept(a2,r2,c2);
 	sparse_matrix(a2,s2,r2,c2);
 	sparse_put(s2);
 	do
 	{
  		printf("\n 1.Fast transpose \n 2.Simple Transpose \n 3.Sparse Addition \n Enter your choice ");
  		scanf("%d",&ch);
  		switch(ch)
  		{
  			case 1:
				fast_transpose(s1,s3);
				sparse_put(s3);
				break;
  			case 2:
				simple_transpose(s1,s4);
				sparse_put(s4);
				break;
			case 3:
				sparse_sum(s1,s2,s5);
				sparse_put(s5);
				break;
  			default:
				printf("Wrong choice");
				break;
  		}//switch
 		printf("\nDo you want to continue,type 1 to continue:");
 		scanf("%d",&ans);
 	}while(ans == 1);
}//main

/*OUTPUT


 Enter Number of the Row and column of matrix 1:2
2
Enter the number of elements in matrix:0
1
2
0

 2 	 2 	 2
------------------------------
 0 	 1 	 1
 1 	 0 	 2
 Enter Number of the Row and column of matrix 2:2
2
Enter the number of elements in matrix:1
2
0
4

 2 	 2 	 3
------------------------------
 0 	 0 	 1
 0 	 1 	 2
 1 	 1 	 4
 1.Fast transpose
 2.Simple Transpose
 3.Sparse Addition
 Enter your choice 1

 2 	 2 	 2
------------------------------
 0 	 1 	 2
 1 	 0 	 1
Do you want to continue,type 1 to continue:1

 1.Fast transpose
 2.Simple Transpose
 3.Sparse Addition
 Enter your choice 2

 2 	 2 	 2
------------------------------
 0 	 1 	 2
 1 	 0 	 1
Do you want to continue,type 1 to continue:1

 1.Fast transpose
 2.Simple Transpose
 3.Sparse Addition
 Enter your choice 3

 2 	 2 	 4
------------------------------
 0 	 0 	 1
 0 	 1 	 3
 1 	 0 	 2
 1 	 1 	 4
Do you want to continue,type 1 to continue:

*/
