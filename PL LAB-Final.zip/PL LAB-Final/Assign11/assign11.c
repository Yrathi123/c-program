/*
 ============================================================================
 Name        : Assign11.c
 Author      : Rucha Shinde
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include<stdio.h>
#include<stdlib.h>

struct Node
{
	char data;
	struct Node *next,*prev;
};
typedef struct Node node;
node *getnode();
node *create();
void display(node *);
node *insertatbeg(node *);
void insertatmid(node *);
void insertatend(node *);
node *deletenode(node *);
void displayback(node *);
int main()
{
	int ch,ans;
	node *head;
	head=create();
	do
	{
		printf("1.Display Forward\n2.Insert at begin\n3.Insert at middle\n4.Insert at end\n5.Delete\n6.Display Backword");
		printf("\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
		case 1:
			display(head);
			break;
		case 2:
			head=insertatbeg(head);
			display(head);
			break;
		case 3:
			insertatmid(head);
			display(head);
			break;
		case 4:
			insertatend(head);
			display(head);
			break;
		case 5:
			head=deletenode(head);
			display(head);
			break;
		case 6:
			displayback(head);
			break;

		default:
			printf("\nInvalid Choice");
		}
		printf("\nDo you want to continue, type 1 to continue:");
		scanf("%d",&ans);
	}while(ans==1);
	return 0;
}
node *getnode()
{
	node *temp;
	temp=(node *)malloc(sizeof(node));
	temp->next=NULL;
	temp->prev=NULL;
	return temp;
}
node *create()
{
	int i=0;char str[10];
	node *p,*q,*temp,*head;
	head=q=p=NULL;
	printf("\nEnter the string:");
	scanf("%s",str);
	while(str[i]!='\0')
	{
		temp=getnode();
		temp->data=str[i];
		if(head==NULL)
		{
			head=temp;
			p=temp;
		}
		else
		{
			p->next=temp;
			temp->prev=p;
			p=temp;
		}
		i++;
	}
	return head;
}
void display(node *p)
{
	while(p!=NULL)
	{
		printf("|%c|->  ",p->data);
		p=p->next;
	}
}
node *insertatbeg(node *head)
{
	char a[10];int i=0;
	node *temp;
	printf("Enter character to insert at begining:");
	scanf("%s",a);
	while(a[i]!='\0')
	{
		temp=getnode();
		temp->data=a[i];
		i++;
	}
	temp->next=head;
	head->prev=temp;
	head=temp;
	return head;
}
void insertatmid(node *head)
{
	int k,i=1,j=0;
	char a[10];
	node *p=head,*q;
	node *temp;
	printf("\nEnter the position of node after which you want to insert new node:");
	scanf("%d",&k);
	printf("Enter character to insert:");
	scanf("%s",a);
	while(i<k)
	{
		q=p;
		p=p->next;
		i++;
	}
	while(a[j]!='\0')
	{
		temp=getnode();
		temp->data=a[j];
		j++;
	}
	temp->next=p->next;
	p->next->prev=temp;
	p->next=temp;
	temp->prev=p;
}

void insertatend(node *p)
{
	node *temp;
	char a[10];int i=0;
	printf("Enter character to insert at end:");
	scanf("%s",a);
	while(a[i]!='\0')
	{
		temp=getnode();
		temp->data=a[i];
		i++;
	}
	while(p->next!=NULL)
	{
		p=p->next;
	}
	p->next=temp;
	temp->prev=p;
}
void displayback(node *head)
{
	node *p=head;
	while(p->next!=NULL)
		p=p->next;
	while(p!=NULL)
	{
		printf(" <-|%c| ",p->data);
		p=p->prev;
	}
}
node *deletenode(node *head)
{
	int k;
	printf("Enter the position of node you want to delete:");
	scanf("%d",&k);
	node *q,*p=head;
	int i=1;
	while(i<k)
	{
		q=p;
		p=p->next;
		i++;
	}
	if(p->next==NULL)
	{
		q->next=NULL;
	}
	else if(p==NULL)
		printf("Data not found");
	else
	{
		q->next=p->next;
		p->next->prev=q;
	}
	free(p);
	return head;
}
/*OUTPUT

Enter the string:pict
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:1
|p|->  |i|->  |c|->  |t|->
Do you want to continue, type 1 to continue:1
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:2
Enter character to insert at begining:P
|P|->  |p|->  |i|->  |c|->  |t|->
Do you want to continue, type 1 to continue:1
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:3

Enter the position of node after which you want to insert new node:3
Enter character to insert:I
|P|->  |p|->  |i|->  |I|->  |c|->  |t|->
Do you want to continue, type 1 to continue:1
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:4
Enter character to insert at end:T
|P|->  |p|->  |i|->  |I|->  |c|->  |t|->  |T|->
Do you want to continue, type 1 to continue:1
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:5
Enter the position of node you want to delete:3
|P|->  |p|->  |I|->  |c|->  |t|->  |T|->
Do you want to continue, type 1 to continue:1
1.Display Forward
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Display Backword
Enter your choice:6
 <-|T|  <-|t|  <-|c|  <-|I|  <-|p|  <-|P|
Do you want to continue, type 1 to continue:2

*/
