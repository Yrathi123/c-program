 /*Quick Sort
 Assignment no. : 7
 Roll no.       : 23163
 Batch          : H9
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include<string.h>
typedef struct
{
	char name[20];
	char mob[11];
	float bill_amt;
}user;
void input(user u[],int total);
void display(user u[],int total);
void quick_sort(user u[],int left,int right,int total);
void swap(user u[],int first,int second);
int main()
{
	setvbuf( stdout, NULL, _IONBF, 0 );
	int total,ch;
	user u[50];
	do{
	printf("Enter the total number of records.\n");
	scanf("%d",&total);
	input(u,total);
	quick_sort(u,0,total-1,total);
	printf("Sorted list:\n");
	display(u,total);
	printf("Do you want to continue:1 if yes,0 if no\n");
	scanf("%d",&ch);
	}while(ch==1);
}
void input(user u[],int total)
{
	int i,j,flag=0;
	for(i=0; i<total; i++)
	{
	    do
        {
           flag=0;
           printf("Enter the name, mobile number and bill amount of user.\n");
           scanf("\n");
           gets(u[i].name);
           scanf("%s%f",u[i].mob,&u[i].bill_amt);
           int l=strlen(u[i].mob);
           if(l!=10)
           {
                printf("Please enter correct mobile number\n");
                flag=1;
           }
           if(flag==0)
           {
        	   for(j=0;j<i; j++)
        	   {
        		   if(strcmp(u[i].mob,u[j].mob)==0)
        		   {
        			   printf("Enter unique mobile number\n");
        			   flag=1;
        		   }
        	   }
           }
        }while(flag==1);
	}
}
void display(user u[],int total)
{
	int i;
	for(i=0; i<total; i++)
	{
		printf("%s\t%s\t%f\n",u[i].name,u[i].mob,u[i].bill_amt);
	}
}
void quick_sort(user u[],int left,int right,int total)
{
	char pivot[20];
	int i,j,comp=0;
	static int it=0;
	if(left<right)
	{
		i=left;
		j=right+1;
		strcpy(pivot,u[left].name);
		do
		{
			do
			{
				i++;
				comp++;
			}while(strcmp(u[i].name,pivot)>0);
			do
			{
				j--;
				comp++;
			}while(strcmp(u[j].name,pivot)<0);
		    if(i<j)
		    	swap(u,i,j);
		    comp++;
		}while(i<j);
		swap(u,left,j);
		printf("Iteration number:%d\n",it+1);
		it++;
		printf("Number of comparisons:%d\n",comp);
		display(u,total);
		printf("\n");
	    quick_sort(u,left,j-1,total);
	    quick_sort(u,j+1,right,total);
	}
}
void swap(user u[],int first,int second)
{
	user temp;
	temp=u[first];
	u[first]=u[second];
	u[second]=temp;
}
/*
Enter the total number of records.
10
Enter the name, mobile number and bill amount of user.
rucha
1111111111
123
Enter the name, mobile number and bill amount of user.
rasika
2222222222
457
Enter the name, mobile number and bill amount of user.
atharva
3333333333
786
Enter the name, mobile number and bill amount of user.
siddhi
44444444444
565
Please enter correct mobile number
Enter the name, mobile number and bill amount of user.
muskan
6666666666
555
Enter the name, mobile number and bill amount of user.
shripad
7777777777
676
Enter the name, mobile number and bill amount of user.
gsuri
8888888888
787
Enter the name, mobile number and bill amount of user.
shreya
9999999999
232
Enter the name, mobile number and bill amount of user.
shraddha
5555555555
787
Enter the name, mobile number and bill amount of user.
neha
1010101010
545
Enter the name, mobile number and bill amount of user.
meena
9090909090
343
Iteration number:1
Number of comparisons:15
shripad 7777777777      676.000000
shraddha        5555555555      787.000000
shreya  9999999999      232.000000
rucha   1111111111      123.000000
muskan  6666666666      555.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
meena   9090909090      343.000000

Iteration number:2
Number of comparisons:5
shripad 7777777777      676.000000
shraddha        5555555555      787.000000
shreya  9999999999      232.000000
rucha   1111111111      123.000000
muskan  6666666666      555.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
meena   9090909090      343.000000

Iteration number:3
Number of comparisons:4
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
muskan  6666666666      555.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
meena   9090909090      343.000000

Iteration number:4
Number of comparisons:10
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
muskan  6666666666      555.000000
atharva 3333333333      786.000000
gsuri   8888888888      787.000000
meena   9090909090      343.000000

Iteration number:5
Number of comparisons:4
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
muskan  6666666666      555.000000
atharva 3333333333      786.000000
gsuri   8888888888      787.000000
meena   9090909090      343.000000

Iteration number:6
Number of comparisons:6
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
muskan  6666666666      555.000000
meena   9090909090      343.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000

Iteration number:7
Number of comparisons:4
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
muskan  6666666666      555.000000
meena   9090909090      343.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000

Sorted list:
shripad 7777777777      676.000000
shreya  9999999999      232.000000
shraddha        5555555555      787.000000
rucha   1111111111      123.000000
rasika  2222222222      457.000000
neha    1010101010      545.000000
muskan  6666666666      555.000000
meena   9090909090      343.000000
gsuri   8888888888      787.000000
atharva 3333333333      786.000000
Do you want to continue:1 if yes,0 if no
0
*/
