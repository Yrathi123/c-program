#include <stdio.h>
#include <stdlib.h>
#
typedef struct student
{
	int r_no;
	char name[50];
	float perc;
}student;
void add(student*[],int);
void display(student*[],int);
void bubble(student*[],int,int);
void selectsort(student* [],int);
int binsr(student* [],int,int);
int binsrec(student* [],int,int,int,int);
int compare(int,int);

int main()
{
   student *s[50];
   int size,i;
	int flag=0,query,pos;
	int choice,cont;
	do
	{
		printf("Enter your choice:\n");
		printf("1.Add Record\n2.Bubble Sort\n3.Selection Sort\n4.Binary Search\n5.Binary(recursive)\n 6.Exit\n");
		scanf("%d",&choice);
		switch(choice)
		{
        case 1:
            printf("Enter no of records:\n");
            scanf("%d",&size);
            add(s,size);
            display(s,size);
            break;
        case 2:
            bubble(s,size,0);
            printf("\nsorted :\n");
            display(s,size);
            break;
        case 3:
            selectsort(s,size);
              printf("\nsorted :\n");
            display(s,size);
            break;
        case 4:
            printf("Enrer the roll no of record you want to search\n");
            scanf("%d",&query);

            bubble(s,size,1);
            pos=binsr(s,query,size);
            						if(pos!=-1)
						{
							printf("\nRecord Found!");
							printf("\nR.No:%d",s[pos]->r_no);
							printf("\nName:%s",s[pos]->name);
							printf("\nPercentage:%f",s[pos]->perc);
							printf("\n\n");
						}
						else
							printf("Record not found!\n");
            break;
            case 5:
            printf("Enrer the roll no of record you want to search\n");
            scanf("%d",&query);

            bubble(s,size,1);
            pos=binsrec(s,query,size,0,size-1);
            						if(pos!=-1)
						{
							printf("\nRecord Found!");
							printf("\nR.No:%d",s[pos]->r_no);
							printf("\nName:%s",s[pos]->name);
							printf("\nPercentage:%f",s[pos]->perc);
							printf("\n\n");
						}
						else
							printf("Record not found!\n");
            break;
        default:
            printf("INVALID CASE\n");
		}
	}while(choice!=6);
    return 0;
}

void add(student* s[],int size)
{
    int i;
    for(i=0;i<size;i++)
    {


		s[i]=malloc(sizeof(size*sizeof(int)));
    }
	for(i=0;i<size;i++)
	{
	    printf("\nEnter roll no:\t");
			scanf("%d",&s[i]->r_no);
			printf("\nEnter name:\t");
		scanf("\n");
		gets(s[i]->name);
		printf("\nEnter percentage:\t");
		scanf("%f",&s[i]->perc);
		printf("\n");
	}
}

void display(student *s[50],int size)
{
    int i;
	for(i=0;i<size;i++)
	{
	    printf("---------------------------\n");
		printf("R.No:%d",s[i]->r_no);
		printf("\nName:%s",s[i]->name);
		printf("\nPercentage:%f",s[i]->perc);
		printf("\n");
        printf("---------------------------\n");
	}
}
void bubble(student *s[50],int size,int flag)
{
    int i,j,check,swap,sorted=0;
    int last=size-1;
    student *temp;
    for(i=0;i<last&&!sorted;i++)
    {
        sorted=1;
        for(j=last;j>i;j--)
        {
            swap=0;check=0;
            if(s[j-1]->r_no > s[j]->r_no)
            {
                temp=s[j-1];
                s[j-1]=s[j];
                s[j]=temp;
                sorted=0;
                swap++;
            }
            if(flag==0)
            {
            printf("Checks:\t%d\tSwap:\t%d\n",check,swap);
						display(s,size);
            }
        }
    }
}

void selectsort(student *s[50],int size)
{
    student *temp;
    int swap,check,i,j,max;
    for(i=0;i<size-1;i++)
    {
        check=0;swap=0;
        max=i;

        for(j=i+1;j<size;j++)
        {
            check=0;swap=0;
            check++;
            if(strcmp(s[j]->name,s[max]->name)>0)
            {
                max=j;
               temp=s[j];
               s[j]=s[max];
               s[max]=temp;
               swap++;
            }
        }
        printf("checks: %d swaps: %d \n",check,swap);
        display(s,size);
    }
}

int binsr(student* s[50],int query ,int size)
{
    int right,left=0,middle;
    right=size-1;
    while(left<=right)
    {

        middle=(left+right)/2;
    switch(compare(s[middle]->r_no,query))
    {
    case -1:
        left=middle+1;
        printf("left:%d \t right:%d \t middle:%d \tmiddle value:%d \t\n",left,right,middle,s[middle]->r_no);
        break;
    case 0:
                printf("left:%d \t right:%d \t middle:%d \tmiddle value:%d \t\n",left,right,middle,s[middle]->r_no);
                return middle;
                break;
    case 1:
        right=middle-1;
        printf("left:%d \t right:%d \t middle:%d \tmiddle value:%d \t\n",left,right,middle,s[middle]->r_no);
        break;

    }

   }
return -1;
}

int binsrec(struct student* s[],int query,int size,int left,int right)
{
	int middle;
	if(left<=right)
	{
		middle=(left+right)/2;
		switch(compare(s[middle]->r_no,query))
		{
			case -1:
				printf("Left=%d,Right=%d,Middle=%d,Middle value=%d\n",left,right,middle,s[middle]->r_no);
				return binsrec(s,query,size,middle+1,right);
				break;
			case 0:
				printf("Left=%d,Right=%d,Middle=%d,Middle value=%d\n",left,right,middle,s[middle]->r_no);
				return middle;
				break;
			case 1:
				printf("Left=%d,Right=%d,Middle=%d,Middle value=%d\n",left,right,middle,s[middle]->r_no);
				return binsrec(s,query,size,left,middle-1);
				break;
		}
	}
	return -1;
}

int compare(int mid,int que)
{
	if(mid<que)
		return -1;
	else if(mid==que)
		return 0;
	else
		return 1;
}
