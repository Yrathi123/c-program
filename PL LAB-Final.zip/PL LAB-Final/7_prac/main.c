#include <stdio.h>
#include <stdlib.h>
#include<string.h>

typedef struct user
{
    char mob[10];
    char name[50];
    int bill;
}user;

void input(user[],int);
void display(user[],int);
void quick_sort(user[],int,int,int);
void swap(user[],int,int);

int main()
{
  int total,ch;
	user u[50];
	do{
	printf("Enter the total number of records.\n");
	scanf("%d",&total);
	input(u,total);
	quick_sort(u,0,total-1,total);
	printf("Sorted list:\n");
	display(u,total);
	printf("\n Do you want to continue: 1-yes 0-no\n");
	scanf("%d",&ch);

	}while(ch==1);
    return 0;
}

void input(user u[50],int total)
{
    int i;
    for(i=0;i<total;i++)
    {
        printf("Enter the name\n");
           scanf("\n");
           gets(u[i].name);
           printf("Enter mobile no\n");
         scanf("%s",u[i].mob);
         printf("Enter bill amount\n");
         scanf("%d",&u[i].bill);
         printf("--------------------------------------------------------------------------------\n");
    }
}

void display(user u[50],int total)
{
    int i;
	for(i=0; i<total; i++)
	{
		printf("\n %s\t%s\t%d\n",u[i].name,u[i].mob,u[i].bill);
	}
}

void swap(user u[50],int first,int second)
{
    user temp;
    temp=u[first];
    u[first]=u[second];
    u[second]=temp;
}

void quick_sort(user u[50],int left,int right,int total)
{
    int i,j;
    char pivot[20];
    int comp=0;
    static int it=0;

    if(left<right)
    {
        i=left;
        j=right+1;
        strcpy(pivot,u[left].name);
    do{
           do{
            i++;
            comp++;
           }while(strcmp(u[i].name,pivot)>0);
            do{
            j--;
            comp++;
        }while(strcmp(u[j].name,pivot)<0);
        if(i<j)
        {
            swap(u,i,j);
        }
            comp++;
    }while(i<j);
    swap(u,left,j);
    printf("Iteration no %d \n",it);
    it++;
    printf("comparisions :%d \n",comp);
    display(u,total);
    quick_sort(u,left,j-1,total);
     quick_sort(u,j+1,right,total);


    }
}
