/*
 ============================================================================
                              FILES
 Assignment no. : 5 (b)
 Roll no.       : 23328
 Batch          : F11
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
typedef struct
{
	int day,month,year;
}date;

typedef struct
{
  int bookno;
  char bookname[100];
  char author[100];
  int price;
  char publisher[100];
  date dissue;
  date dret;

}library;
void create(library b,int total);
void display(library D);
void add(library b,int total);
int search(library b,int n);
void update(library D,int n);
void delete(library D,int n);
int main()
{
	int choice,n,f,total;
	library b,D;
	printf("Enter total no. of records\n");
	scanf("%d",&total);
	if(total!=0)
		create(b,total);
	do
	{
		printf("1. Display records \n");
		printf("2. Add record \n");
		printf("3. Search record \n");
		printf("4. Update record \n");
		printf("5. Delete record \n");
		printf("6. Exit \n");
		printf("Enter your choice \n");
		scanf("%d",&choice);
		switch(choice)
		{
		  case 1:
				 display(D);
				 break;
		  case 2:
				 add(b,total);
				 total++;
				 break;
		  case 3:
				 printf("Enter the book number to be searched \n");
				 scanf("%d", &n);
				 f=search(b,n);
				 if(f==-1)
					 printf("Record not found \n");
				 else
					 printf("Record found \n");
				 break;
		  case 4:
				 printf("Enter the book number whose record is to be modified \n");
				 scanf("%d", &n);
				 f=search(b,n);
				 if(f==-1)
					 printf("Record not found \n");
				 else
					 update(b,n);
					 printf("Updated successfully\n");
				 break;
		  case 5:
				  printf("Enter the book number whose record is to be deleted \n");
				  scanf("%d",&n);
				  f=search(b,n);
				 if(f==-1)
					 printf("Record not found \n");
				 else
				 {
					 delete(b,n);
					 printf("Deleted successfully\n");
					 total--;
				 }
				  break;
		  case 6:
				 printf("THANK YOU \n");
				 break;
          default:
                 printf("Enter correct number\n");
		}
	}while(choice!=6);
   return 0;
}
void create(library b,int total)
{
	int i,no;
	no=1;
	FILE *fp;
	fp=fopen("library.bin","w+");
	if(fp==NULL)
	{
		exit(0);
	}
	for(i=0; i<total; i++)
        b.bookno=no;

	{

	    	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",b.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       //scanf("\n");
	       scanf("%s",b.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&b.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      // scanf("\n");
	       scanf("%s",b.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&b.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&b.dret.month);
	       	       printf("\n Enter year");
	       	       	 ///      fflush(0);
	       	       scanf("%d",&b.dret.year);

        fwrite(&b,sizeof(library),1,fp);
        no++;
    }
	//display(fp);
	fclose(fp);
}
void display(library D)
{
	FILE *fp;
	fp=fopen("library.bin","r");
	if(fp==NULL)
		exit(0);
	while(fread(&D,sizeof(library),1,fp)==1)
	{
		printf("%d \t\t\t %s \t\t %d \t\t\t %s \t\t\t %d%d/%d \t\t\t %d/%d/%d \n", D.bookno,D.bookname, D.price, D.publisher, D.dissue.day,D.dissue.month,D.dissue.year, D.dret.day,D.dret.month,D.dret.year);
	}
	fclose(fp);
}
void add(library b,int total)
{
	int no;
	FILE *fp;
	fp=fopen("library.bin","r");
	while(fread(&b,sizeof(library),1,fp)==1)
	{
				no=b.bookno;
	}
	fclose(fp);
	fp=fopen("library.bin","a");
	printf("Enter datails\n");
	scanf("\n");
	b.bookno=no+1;
	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",b.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       scanf("\n");
	       scanf("%s",b.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&b.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      scanf("\n");
	       scanf("%s",b.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&b.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&b.dret.month);
	       	       printf("\n Enter year");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.year);



    fwrite(&b,sizeof(library),1,fp);
    fclose(fp);
}
int search(library D,int n)
{
	FILE *fp;
	fp=fopen("library.bin","r");
	while(fread(&D,sizeof(library),1,fp)==1)
	{
		if(D.bookno==n)
			return 1;
	}
	return -1;
}
void update(library D,int n)
{
	FILE *fp;
	fp=fopen("library.bin","r+");
	FILE *fp1;
	fp1=fopen("library.bin","w+");
	while(fread(&D,sizeof(library),1,fp)==1)
	{
	     if(D.bookno!=n)
	     {
	        fwrite(&D,sizeof(library),1,fp1);
	     }
	     else
	     {
	    	 D.bookno=n;
			 printf("Enter datails\n");
	scanf("\n");

	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",D.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       scanf("\n");
	       scanf("%s",D.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&D.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      scanf("\n");
	       scanf("%s",D.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&D.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&D.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&D.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&D.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&D.dret.month);
	       	       printf("\n Enter year");
	       	       	 //      fflush(0);
	       	       scanf("%d",&D.dret.year);


             fwrite(&D,sizeof(library),1,fp1);
	     }
	}
	fclose(fp);
	fclose(fp1);
	 remove("library.bin");
	 rename("library.bin","lib.bin");
}
void delete(library D,int n)
{
    FILE *fp;
	fp=fopen("library.bin","r+");
	FILE *fp1;
	fp1=fopen("lib.bin","w+");
	while(fread(&D,sizeof(library),1,fp)==1)
	{
        if(D.bookno!=n)
        {
           fwrite(&D,sizeof(library),1,fp1);
        }
	}
	fclose(fp);
	fclose(fp1);
	 remove("library.bin");
	 rename("library.bin","lib.bin");
}
