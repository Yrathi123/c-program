#include <stdio.h>
#include <stdlib.h>
#define maxsize 100

typedef struct
{
	int day,month,year;
}date;

typedef struct library
{
    int bookno;
  char bookname[100];
  char author[100];
  int price;
  char publisher[100];
  date dissue;
  date dret;
}library;

void create(library[],int);
void display(library[],int,int);
void add(library[],int);
void search(library[],int);
void modify(library[],int);
void delete(library[],int);

void create(library s[maxsize],int i)
{

    printf("Enter data for book no %d",i+1);
		 /// fflush(0);

	    	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",s[i].bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       //scanf("\n");
	       scanf("%s",s[i].author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&s[i].price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      // scanf("\n");
	       scanf("%s",s[i].publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&s[i].dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&s[i].dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&s[i].dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&s[i].dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&s[i].dret.month);
	       	       printf("\n Enter year");
	       	       	 ///      fflush(0);
	       	       scanf("%d",&s[i].dret.year);


}

void display(library s[maxsize],int i)
{

		printf(" \n %d \t",i+1);
		fflush(0);
		printf("    %s ",s[i].bookname);
		fflush(0);
		printf("  %s \t",s[i].author);
		fflush(0);
		printf("%d \t",s[i].price);
		fflush(0);
		printf("%s \t\t",s[i].publisher);
		fflush(0);
		printf("%d-",s[i].dissue.day);
		fflush(0);
		printf("%d-",s[i].dissue.month);
		fflush(0);
		printf("%d \t",s[i].dissue.year);
		fflush(0);
		printf("%d-",s[i].dret.day);
		fflush(0);
		printf("%d-",s[i].dret.month);
		fflush(0);
		printf("%d ",s[i].dret.year);
		fflush(0);

}



int main()
{
    int ch,no,i;
    library s[maxsize];
    printf("Enter no of records you want to enter:\n");
    scanf("%d",&no);

        create(s,no,i);


    do{
            printf("\n------------------------------------------------------------------------\n");
            printf("1.Display \n 2.Add \n 3.search \n 4.Modify \n 5.modify \n 6.Exit\n");
            printf("Enter your choice:\n");
        scanf("%d",&ch);

        switch(ch)
        {
        case 1:
            printf("\n BOOK ID \t name\t author \t price \t publisher \t date issue \t date ret");
            for(i=0;i<no;i++)
            {
             display(s,no,i);
            }
            break;
        case 2:
           printf("add new record:\n");
           create(s,no,i+1);
           no++;
            for(i=0;i<=no;i++)
            {
             display(s,no,i);
            }



            break;



        }

    }while(ch!=6);

    return 0;
}
