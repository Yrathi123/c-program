/*
 ============================================================================
 Name        : matrixoperations.c
 Author      : Rucha Shinde
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#define Maxsize 100

void input(int[Maxsize][Maxsize],int,int);
void display(int[Maxsize][Maxsize],int,int);
void addition(int[Maxsize][Maxsize],int,int,int[Maxsize][Maxsize],int,int,int[Maxsize][Maxsize]);
void transpose(int[Maxsize][Maxsize],int,int,int[Maxsize][Maxsize]);
void multi(int[Maxsize][Maxsize],int,int,int[Maxsize][Maxsize],int,int,int[Maxsize][Maxsize]);
void saddle(int[Maxsize][Maxsize],int);
int main()
{
int mat1[100][100],r1,c1,mat2[100][100],r2,c2,mat3[100][100],ch,s;
 do{
  printf(" \n Enter your choice\n 1.Addition \n 2.Transpose \n 3.multiplication \n 4.saddle point \n 5.exit \n");
  fflush(0);
  scanf("%d",&ch);
  printf("choice is %d \n",ch);

switch(ch)
{
case 1:
	{
		printf("ENTER rows for 1st matrix \t");
		fflush(0);
		scanf("%d",&r1);
		printf("ENTER columns for 1st matrix \t");
		fflush(0);
	     scanf("%d",&c1);


	     printf("ENTER rows for 2nd matrix \t");
	     fflush(0);
	     scanf("%d",&r2);
	     printf("ENTER columns for 2nd matrix \t");
	     fflush(0);
	     scanf("%d",&c2);

	     printf("\nEnter elements of  first matrix ");
	     fflush(0);

	     input(mat1,r1,c1);
	     display(mat1,r1,c1);

	     printf("\n Enter elements of second matrix ");
	     fflush(0);

	     input(mat2,r2,c2);
	     display(mat2,r2,c2);

          addition(mat1,r1,c1,mat2,r2,c2,mat3);
          printf("\n Elements of addition matrix are \t");
       	    	fflush(0);
          display(mat3,r1,c1);

             break;
	 }
case 2:
      {
	        printf("ENTER rows for matrix \t");
			fflush(0);
			scanf("%d",&r1);
			printf("ENTER columns for matrix \t");
			fflush(0);
		    scanf("%d",&c1);

		    printf("\n Enter elements of matrix");
		     fflush(0);
            input(mat1,r1,c1);
            display(mat1,r1,c1);

            transpose(mat1,r1,c1,mat3);
            printf("\n Elements of transpose matrix are");
                       fflush(0);
	      display(mat3,c1,r1);
            break;
      }
case 3:
    {

	printf("ENTER rows for 1st matrix \t");
	fflush(0);
	scanf("%d",&r1);
	printf("ENTER columns for 1st matrix \t");
	fflush(0);
     scanf("%d",&c1);

     printf("ENTER rows for 2nd matrix \t");
     fflush(0);
     scanf("%d",&r2);
     printf("ENTER columns for 2nd matrix \t");
     fflush(0);
     scanf("%d",&c2);
     if(r2!=c1)
      {
         	printf("\n multiplication is not possible");
      }
      else
      {
    	  printf("\n Enter elements of  first matrix");
    	  	    	fflush(0);

    	  input(mat1,r1,c1);
    	  display(mat1,r1,c1);

    	  printf("\n Enter elements of second matrix");
    	  	    	fflush(0);

    	  input(mat2,r2,c2);
    	  	     display(mat2,r2,c2);

    	  multi(mat1,r1,c1,mat2,r2,c2,mat3);
    	  printf("\n Elements of multiplication matrix are");
    	                       fflush(0);
    	         display(mat3,r1,c2);
      }
   
 case 4:
  {
    	printf(" \nENTER no of rows   for matrix \t");
        fflush(0);
        scanf("%d",&r1);
        printf(" \nENTER  no of columns  for matrix \t");
        fflush(0);
        scanf("%d",&c1);
    if(r1==c1)
    {
        printf("\n Enter elements of matrix");
        fflush(0);
        input(mat1,r1,r1);
        display(mat1,r1,r1);
        saddle(mat1,r1);
   }
       else
       {
           printf("Enter same no of rows and columns");
       }


         break;
}
}
}while(ch!=5);
return 0;
}

void input(int mat1[Maxsize][Maxsize],int r1,int c1)
{

	int i,j;

    for(i=0;i<r1;i++)
    {

        for(j=0;j<c1;j++)
        {
            scanf("%d",&mat1[i][j]);

        }
    }
}

void display(int mat1[Maxsize][Maxsize],int r1,int c1)
{
int i,j;

    for(i=0;i<r1;i++)
    { printf("\n");
        for(j=0;j<c1;j++)
        {
            printf("%d",mat1[i][j]);
            printf("\t\t ");
        }
    }
}

 void addition(int mat1[Maxsize][Maxsize],int r1,int c1,int mat2[Maxsize][Maxsize],int r2,int c2,int mat3[Maxsize][Maxsize])
{
	 int i,j;
	 if((r1==r2)&&(c1==c2))
	 {
        for(i=0;i<r1;i++)
       {
        for(j=0;j<c1;j++)
            {mat3[i][j]= mat1[i][j]+ mat2[i][j];}
        }
     }
	 else
	 {
		 printf("Addiiton not possible");
	 }
}

 void transpose(int mat1[Maxsize][Maxsize],int r1,int c1,int mat3[Maxsize][Maxsize])
 {
	 int i,j;
	 for(i=0;i<r1;i++)
	 {
		 for(j=0;j<c1;j++)
		 {
			mat3[i][j]=mat1[j][i];
		 }
	  }

 }

 void multi(int mat1[Maxsize][Maxsize],int r1,int c1,int mat2[Maxsize][Maxsize],int r2,int c2,int mat3[Maxsize][Maxsize])
 {
	 int i,j,k,sum=0;

	for(i=0;i<r1;i++)
	{
		for(j=0;j<c2;j++)
		{
			for(k=0;k<c1;k++)
		sum=sum+mat1[i][k]*mat2[k][j];
			{
				mat3[i][j]=sum;
				sum=0;
			}
		}
     }
  }

void saddle(int mat1[Maxsize][Maxsize],int num)
{

int s,i,j,p,l,flag;

   for (i = 0; i < num; i++)
    {
        p = 0;
        s= mat1[i][0];
        for (j = 0; j < num; j++)
         {
            if (s>= mat1[i][j])
             {
                s = mat1[i][j];
                p = j;
            }
        }
        l= 0;
        for (j = 0; j < num; j++)
         {
            if (l < mat1[j][p])
            {
                l = mat1[j][p];
            }
        }

        if (s== l)
            {
            printf("\n value of Saddle Point :%d \n",s);
            printf("saddle point is at location %d %d",j,i);
            flag = 0;
          }
    }

    if (flag > 0)
        {
        printf("saddle point is not found");
       }

}



