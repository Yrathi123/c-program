/*
 ============================================================================
 Name        : SetOperation.c
 Author      : Rucha Shinde
 Roll no.-23163      Batch:H9
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

//prototype declarations
int input(int [],int);
void display(int[],int);
int intersection(int[],int,int[],int,int[]);
int show_union(int[],int,int[],int,int[]);
int show_diff(int[],int,int[],int,int[]);
int symdiff(int[],int,int[],int,int[]);

//Main funciton
void main()
{
    int i,j,k=0,a[10],b[10],c[10],ch=1,n1,n2;
    //Input & display array elements from user
      n1=input(a,n1);
      display(a,n1);
      n2=input(b,n2);
      display(b,n2);

    // option selection by for user
     printf("enter your choice \n 1.intersection \n 2.union \n 3. Difference \n 4.symmetric difference");
	 fflush(0);
     scanf("%d",&ch);

     //switch cases
  switch (ch)
  {
  case 1:
     k=intersection(a,n1,b,n2,c);
     display(c,k);
     break;
  case 2:
	  k=show_union (a,n1,b,n2,c);
	  display(c,k);
	  break;
  case 3:
	  k=show_diff(a,n1,b,n2,c);
	  display(c,k);
	  break;
  case 4:
      k=symdiff(a,n1,b,n2,c);
	  display(c,k);
	  break;

	}


}

//input 1st array
int input(int a[10],int n1)
{
int i,j;
printf("Enter number of elements of array ");
		scanf("%d",&n1);

        do
		{
			if(n1<0 || n1>10)
			{
				printf("Enter correct limits\n");
				fflush(0);
				scanf("%d",&n1);
            }
			else
                break;
		}while(1);

		//accepting array based on the input limits

		printf("\n Enter values of array \n");
		fflush(0);
		for( i=0;i<n1;i++)
			{
				scanf("%d",&a[i]);
				for(j=i-1;j>=0;j--)
					{
						if(a[j] == a[i])
						{
							printf("No repetitions are allowed in a set\n");
							fflush(0);
							i--;
						continue;
						}
						else break;
					}
			}
return n1;
}



//display 1 st array
void display(int a[10], int n1)
{
	int i;
	printf("\n elements of  array are");
	fflush(0);
		for (i=0;i<n1;i++)
		{
		    printf("%d",a[i]);
		    fflush(0);
        }
}



//intersection

int intersection(int a[10],int n1,int b[10],int n2,int c[10])
{
	int i,j,m=0,k=0;
	for (i=0;i<n1;i++)
		{
			for (j=0;j<n2;j++)
			{
				if( a[i] == b[j])
				{
					c[k]=a[i];
					k++;
				}
	        }
		 }


}

//union
int show_union(int a[10],int n1,int b[10],int n2,int c[10])
{
	int i,j,m=0,k=0,flag;
	//copying elements of A
			for (i=0;i<n1;i++)
			{
				c[k]=a[i];
				k++;
			}

			for (j=0;j<n2;j++)
			{
				flag=0;
				for (i=0;i<n1;i++)
				{
				if(b[j]==a[i])
					{
						flag=1;
						break;
					}
				}

					if(flag==0)
					{
						c[k]=b[j];
						k++;
					}
               }
               return k;

}

//diff
int  show_diff(int a[10],int n1,int b[10],int n2,int c[10])
{
	int i,j,m=0,k=0,flag;
	for (i=0;i<n1;i++)

					{
						flag=0;
						for (j=0;j<n2;j++)
						{
						if(b[j]==a[i])
							{
								flag=1;
								break;
							}
						}

							if(flag==0)
							{
								c[k]=a[i];
								k++;
							}
					}

return k;
}

//symmetric difference
int symdiff(int a[10],int n1,int b[10],int n2,int c[10])
{
    int d1[10],d2[10],sd1,sd2,k;
    sd1=show_diff(a,n1,b,n2,d1);
    sd2=show_diff(b,n2,a,n1,d2);
    k=show_union(d1,sd1,d2,sd2,c);
    return k;
}

