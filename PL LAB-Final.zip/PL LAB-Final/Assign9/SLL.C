/*
 ============================================================================
 Name        : linklist.c
 Author      : Rucha Shinde
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdio.h>
#include <stdlib.h>
struct Node
{
	int data;
	struct Node *next;
};
typedef struct Node node;
node *getnode();
node *create();
void display(node *);
node *insertatbeg(node *);
void insertatmid(node *);
void insertatend(node *);
node *deletenode(node *);
void reverse(node *);
node *revert(node *);
int main()
{
	int ch,ans;
	node *head;
	head=create();
	do
	{
		printf("1.Display\n2.Insert at begin\n3.Insert at middle\n4.Insert at end\n5.Delete\n6.Reverse the list\n7.Revert the SLL ");
		printf("\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
		case 1:
			display(head);
			break;
		case 2:
			head=insertatbeg(head);
			display(head);
			break;
		case 3:
			insertatmid(head);
			display(head);
			break;
		case 4:
			insertatend(head);
			display(head);
			break;
		case 5:
			head=deletenode(head);
			display(head);
			break;
		case 6:
			reverse(head);
			break;
		case 7:
			head=revert(head);
			display(head);
			break;
		default:
			printf("\nInvalid Choice");
		}
		printf("\nDo you want to continue, type 1 to continue:");
		scanf("%d",&ans);
	}while(ans==1);
	return 0;
}

node *getnode()
{
	node *temp;
	temp=(node *)malloc(sizeof(node));
	printf("Enter element to create node:");
	scanf("%d",&temp->data);
	temp->next=NULL;
	return temp;
}
node *create()
{
	int ans;
	node *p,*q,*temp;
	p=q=NULL;
	do
	{
		temp=getnode();
		if(p==NULL)
		{
			p=temp;
			q=p;
		}
		else
		{
			q->next=temp;
			q=q->next;
		}
		printf("Do you want to insert a node again,type 1 to insert:");
		scanf("%d",&ans);
	}while(ans==1);
	return p;
}
void display(node *p)
{
	while(p!=NULL)
	{
		printf("|%d|->  ",p->data);
		p=p->next;
	}
}

node *insertatbeg(node *p)
{
	node *temp=getnode();
	temp->next=p;
	p=temp;
	return p;
}
void insertatmid(node *p)
{
	int k;
	node *temp=getnode();
	printf("\nEnter the data after which you want to insert new node:");
	scanf("%d",&k);
	while(p->next!=NULL && p->data!=k)
	{
		p=p->next;
	}
	temp->next=p->next;
	p->next=temp;
}
void insertatend(node *p)
{
	node *temp=getnode();
	while(p->next!=NULL)
	{
		p=p->next;
	}
	p->next=temp;
}
node *deletenode(node *head)
{
	int k;
	printf("Enter the data of node which you want to delete:");
	scanf("%d",&k);
	node *q,*p=head;
	while(p->data!=k && p!=NULL)
	{
		q=p;
		p=p->next;
	}
	if(p==NULL)
		printf("Data not found");
	else
	{
		q->next=p->next;
	}
	free(p);
	return head;
}
void reverse(node *head)
{
	if(head!=NULL)
	{
		reverse(head->next);
		printf("<-|%d| ",head->data);
	}
}
node *revert(node *head)
{
	node *s=NULL,*p=head->next,*q=head;
	while(q!=NULL)
	{
		q->next=s;
		s=q;
		q=p;
		if(p!=NULL)
		  p=p->next;
	}
	return s;
}

/*OUTPUT

Enter element to create node:2
Do you want to insert a node again,type 1 to insert:1
Enter element to create node:3
Do you want to insert a node again,type 1 to insert:1
Enter element to create node:5
Do you want to insert a node again,type 1 to insert:1
Enter element to create node:6
Do you want to insert a node again,type 1 to insert:2
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:1
|2|->  |3|->  |5|->  |6|->
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:2
Enter element to create node:1
|1|->  |2|->  |3|->  |5|->  |6|->
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:3
Enter element to create node:4

Enter the data after which you want to insert new node:3
|1|->  |2|->  |3|->  |4|->  |5|->  |6|->
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:4
Enter element to create node:7
|1|->  |2|->  |3|->  |4|->  |5|->  |6|->  |7|->
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:5
Enter the data of node which you want to delete:3
|1|->  |2|->  |4|->  |5|->  |6|->  |7|->
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:6
<-|7| <-|6| <-|5| <-|4| <-|2| <-|1|
Do you want to continue, type 1 to continue:1
1.Display
2.Insert at begin
3.Insert at middle
4.Insert at end
5.Delete
6.Reverse the list
7.Revert the SLL
Enter your choice:7
|7|->  |6|->  |5|->  |4|->  |2|->  |1|->
Do you want to continue, type 1 to continue:2

*/
