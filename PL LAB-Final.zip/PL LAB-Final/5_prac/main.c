#include <stdio.h>
#include <stdlib.h>
#include<string.h>



typedef struct
{
	int day,month,year;
}date;

typedef struct
{
  int bookno;
  char bookname[100];
  char author[100];
  int price;
  char publisher[100];
  date dissue;
  date dret;

}library;

void create( library,int);
void display( library);
void insert(library,int);
void search(library,int);
void update(library,int);
void delete(library,int);

void main()
{
  int no,ch,i,insbook,sbook,upbook,delbook;
  library D;
  library b;
  printf("Enter no. of records you want to enter");

  scanf("%d",&no);
if(no!=0)
	  create(b,no);



do
{
  printf("\n1.Display\n 2.insert \n 3.search \n 4.update \n 5.Delete \n 6.Exit");
//  fflush(0);
  printf(" \n Enter your choice");
 // fflush(0);
  scanf("%d",&ch);


  switch(ch)
  {
  case 1:
	 printf("\n BOOK ID \t name\t author \t price \t publisher \t date issue \t date ret");
	 display(D);
	 break;

case 2:

	  insert(b,no);
      no++;
	  break;
  case 3:
      printf("Enter Id of book which you want to search");
      scanf("%d",&sbook);
      search(b,sbook);

      break;
  case 4:
	  printf("Enter Id of a book which you want to update");
	  scanf("%d",&upbook);
       update(b,upbook);
      break;
/*
  case 5:
 	  printf("Enter Id of a book which you want to delete");
 	  scanf("%d",&delbook);
       delete(b,delbook);
       break;
*/

  }

}while(ch!=6);


}


//to input records
void create( library b,int no)
{
	int i,n;
	n=1;
	FILE *fp;
	fp=fopen("library.bin","w+");
	if(fp==NULL)
    {
        exit(0);
    }
	 for(i=0;i<no;i++)

	  {
	        b.bookno=n;
	      printf("Enter data for book no %d",n);
		 // fflush(0);

	    	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",b.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       //scanf("\n");
	       scanf("%s",b.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&b.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      // scanf("\n");
	       scanf("%s",b.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&b.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&b.dret.month);
	       	       printf("\n Enter year");
	       	       	 ///      fflush(0);
	       	       scanf("%d",&b.dret.year);
            fwrite(&b,sizeof(library),1,fp);
            n++;
		}
		fclose(fp);
}

void display(library D)
{
    int n=1;
	FILE *fp;
	fp=fopen("library.bin","r");
	if(fp==NULL)
    {
        exit(0);
    }
	while(fread(&D,sizeof(library),1,fp)==1)
    {
        D.bookno=n;
        printf("  \n %s ",D.bookname);
		fflush(0);
		printf("  %s \t",D.author);
		fflush(0);
		printf("%d \t",D.price);
		fflush(0);
		printf("%s \t\t",D.publisher);
		fflush(0);
		printf("%d-",D.dissue.day);
		fflush(0);
		printf("%d-",D.dissue.month);
		fflush(0);
		printf("%d \t",D.dissue.year);
		fflush(0);
		printf("%d-",D.dret.day);
		fflush(0);
		printf("%d-",D.dret.month);
		fflush(0);
		printf("%d ",D.dret.year);
		fflush(0);
		n++;
    }
    fclose(fp);
}

void insert (library b,int no)
{
    int n;
    n=1;
    FILE *fp;
    fp=fopen("library.bin","r");
    while(fread(&b,sizeof(library),1,fp)==1)
    {
        n=b.bookno;
    }
    fclose(fp);
     fp=fopen("library.bin","a+");
     {
         b.bookno=n+1;
         printf("Enter data for book no %d",n+1);
		 /// fflush(0);

	    	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",b.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       scanf("\n");
	       scanf("%s",b.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&b.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      scanf("\n");
	       scanf("%s",b.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&b.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&b.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&b.dret.month);
	       	       printf("\n Enter year");
	       	       	 //      fflush(0);
	       	       scanf("%d",&b.dret.year);
               fwrite(&b,sizeof(library),1,fp);
     }
     fclose(fp);


}

void search(library b,int sbook)
{
	int i,flag=0;

	FILE *fp;
	fopen("library.bin","r");
	while(fread(&b,sizeof(library),1,fp)==1)
    {

        if(b.bookno==sbook)
            flag=1;
    }
    if(flag==1)
    {
        printf("FOUND\n");
    }
    else
        printf("NOT FOUND\n");

}

void update(library D,int upbook)
{
    int n=1;
	FILE *fp;
	fopen("library.bin","r+");
	FILE *fp1;
	fopen("library.bin","w+");
		while(fread(&D,sizeof(library),1,fp)==1)
        {
            if(D.bookno!=n)
            {
                fwrite(&D,sizeof(library),1,fp1);
            }
        else{
                D.bookno=n;
                 printf("Enter data for book no %d",n);
		 // fflush(0);

	    	printf("\n Enter Title of book");
	    	//fflush(0);

	    	scanf("%s",D.bookname);

	    	printf("\n Enter author of book");
	    	//fflush(0);
	       //scanf("\n");
	       scanf("%s",D.author);

	       printf(" \nEnter price of book");
	       //fflush(0);
	       scanf("%d",&D.price);

	       printf(" \n Enter publisher of book");
	       //fflush(0);
	      // scanf("\n");
	       scanf("%s",D.publisher);
//date of issue

	       printf("\n Enter date of issue");
	       	//       	       fflush(0);
	       	       	       printf("\n Enter day");
	       	  //     	       	       fflush(0);
	       	       	       scanf("%d",&D.dissue.day);
	       	       	       printf("\n Enter month");
	       	    //   	       	       fflush(0);

	       	       	       scanf("%d",&D.dissue.month);
	       	       	       printf("\n Enter year");
	       	      // 	       	       fflush(0);
	       	       	       scanf("%d",&D.dissue.year);

//date of return

	       printf("\n Enter date of return");
	       	       //fflush(0);
	       	       printf("\n Enter day");
	       	       	 //      fflush(0);
	       	       scanf("%d",&D.dret.day);
	       	       printf("\n Enter month");
	       	       //	       fflush(0);

	       	       scanf("%d",&D.dret.month);
	       	       printf("\n Enter year");
	       	       	 ///      fflush(0);
	       	       scanf("%d",&D.dret.year);
            fwrite(&D,sizeof(library),1,fp1);


	}
}

	fclose(fp);
	fclose(fp1);
	remove("library.bin");
	rename("library.bin","lib.bin");
}
/*
void delete(library s[100],int no,int delbook)
{
	  int i;
	while(delbook<=no)
	{
	  s[delbook-1]=s[delbook];
	  delbook++;

      }

}
*/
