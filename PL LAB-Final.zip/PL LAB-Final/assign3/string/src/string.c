/*
 ============================================================================
 Name        : string.c
 Author      : Rucha Shinde
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#define maxsize 20

int length(char[]);
int compare(char[],char[]);
void reverse(char[],char[]);
void copy(char[],char[]);
int palindrome(char[],char[]);
int substring(char[],char[]);

int main()
{
	char str1[maxsize],str2[maxsize],search[maxsize];
	int ch,l,pal,a,b;

do
{
    printf("\n Enter your choice \n");
	fflush(0);
	printf("1.length \n 2.compare \n 3.reverse \n 4. copy \n 5.palindrome \n 6. substring \n7.exit  \n");
	fflush(0);
	scanf("%d",&ch);
 printf("\n Choice is %d \n",ch);

switch(ch)
   {
case 1:
	printf("Enter the string");
	fflush(0);
	scanf("\n");
	scanf("%s",str1);
	l=length(str1);
	printf("Length of the string is %d",l);
	fflush(0);
	break;

case 2:
	printf("Enter first string");
	fflush(0);
	scanf("\n");
		scanf("%s",str1);
	printf("Enter second string");
	fflush(0);
	scanf("\n");
		scanf("%s",str2);

	a=compare(str1,str2);
	 if(a==0)
     {
         printf("strings are same");
     }
     else
         printf("strings are  not same");
	break;

case 3:
	printf("Enter string you want to reverse");
	fflush(0);
	scanf("\n");
	scanf("%s",str1);
	reverse(str1,str2);
	printf("Reverse of the string is");

	fflush(0);
	printf("\n");
	puts(str2);
	break;

case 4:
    printf("Enter the  string you want to copy");
	fflush(0);
	scanf("\n");
		scanf("%s",str1);
	copy(str1,str2);
	printf("copy of the string is \n");
	fflush(0);

	printf("%s",str2);
	break;

case 5:
	printf("Enter first string");
	fflush(0);
	scanf("\n");
	scanf("%s",str1);
	printf("Enter second string");
	fflush(0);
	scanf("\n");
	scanf("%s",str2);
    pal=palindrome(str1,str2);
    if(pal==0)
     {
         printf("Palindrome is present");
         	fflush(0);

     }
     else
         printf("Palindrome is not present");
         	fflush(0);


    break;


case 6:
	printf("Enter first string");
	fflush(0);
	scanf("\n");
	scanf("%s",str1);
	printf("Enter search substring");
	fflush(0);
	scanf("\n");
	scanf("%s",search);

	 b=substring(str1,search);
	 if(b==1)
     {
        printf("The substring is not present in given string\n");

     }
     else
      printf("The substring is present in given string\n");
	 break;


   }
}while(ch!=7);
return 0;
}

int length(char str1[maxsize])
{
	int i=0;
	while(str1[i]!='\0')
	{
		i++;
	}
return i;
}

int compare(char str1[maxsize],char str2[maxsize])
{
  int i=0,j,len,flag;
  for(i=0;str1[i]!='\0';i++)
  {
      if(str1[i]!=str2[i])
        return (str1[i]-str2[j]); //strings are not equal.
  }
  return 0; //strings are equal.
}




void reverse(char str1[maxsize],char str2[maxsize])
{
	int i,len=0,j;
		len=length(str1);
		for(i=0,j=len-1;i<len,j>=0;i++,j--)
		{
		str2[j]=str1[i];
		}
}

void copy(char str1[maxsize],char str2[maxsize])
{
	int i=0;
		while(str1[i]!='\0')
		{
			str2[i]=str1[i];
			i++;

        }
        str2[i]='\0';
}



int palindrome(char str1[maxsize],char str2[maxsize])
{
	int i;
	char rev[maxsize];

    reverse(str2,rev);
   i=compare(str1,rev);
    return i;

}


int substring(char str1[maxsize],char search[maxsize])
{
 int i,j,temp;


    for(i=0;str1[i]!='\0';i++)
    {
        j=0;
        if(str1[i]==search[j])
        {
            temp=i+1;
            while(str1[i]==search[j])
            {
                i++;
                j++;
            }

            if(search[j]=='\0')
            {
                printf("The substring is present in given string ");

            }
            else
            {
                i=temp;
                temp=0;
            }
        }
    }
    if(temp==0)
       return 1;
    else
        return 0;
}





