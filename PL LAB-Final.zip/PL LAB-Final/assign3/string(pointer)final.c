 /*
 ============================================================================
 Assignment No.	    : 3.2
 Name           	: string Operation with pointers
 Author     		: Rucha Shinde
 Roll no.	 		: 23163
 Class   	 	    : SE - 9
 Batch				: H9
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#define maxsz 20

int main() {
	char s1[maxsz],s2[maxsz],rev[maxsz],cpy[maxsz],pal[maxsz];
	int a,n;
	int length(char *);
	int compare(char*,char *);
	void reverse(char *,char *);
	void copy(char *,char *);
	int palindrome(char*,char *);
	int substring(char *,char *);
do{
	printf("Enter the option:-\n1.Length\n2.Compare\n3.Reverse\n4.Copy\n5.Palindrome\n6.Substring\n7.Exit");
	scanf("%d",&n);


	switch(n){
	case 1:
		printf("Enter the string");
		scanf("\n");
		gets(s1);
		a=length(s1);
		printf("%d\n",a);
		break;

	case 2:
		printf("Enter the first string to compare");
		scanf("\n");
		gets(s1);
		printf("Enter the second string to compare");
		scanf("\n");
		gets(s2);
		a=compare(s1,s2);
		if(a==0){
			printf("String 1 is above than String 2\n");
		}
		else if(a==1){
			printf("string 2 is above than String 1\n");
		}
		else{
			printf("Strings are same\n");
		}
		break;

	case 3:
		printf("Enter the string");
		scanf("\n");
		gets(s1);
		reverse(s1,rev);
		printf("%s\n",rev);
		break;

	case 4:
		printf("Enter the string");
		scanf("\n");
		gets(s1);
		copy(s1,cpy);
         printf(" Copy of the string is :%s \n ",cpy);
		break;

	case 5:
        printf("Enter the first string");
		scanf("\n");
		gets(s1);
		printf("Enter the second string ");
		scanf("\n");
        gets(pal);
		a=palindrome(s1,pal);
		if(a==0){
			printf("Palindrome present\n");
		}
		else{
			printf("Not palindrome\n");
		}
		break;

	case 6:
		printf("Enter the first string");
		scanf("\n");
		gets(s1);
		printf("Enter the second string ");
		scanf("\n");
		gets(s2);
		a=substring(s1,s2);
		if(a==0){
			printf("Not a substring\n");
		}
		else{
			printf("substring found %d times\n",a);
		}
		break;

	}
}while(n!=7);

	return 0;
}

int length(char *s){
	int i;
	for(i=0;*(s+i)!='\0';i++);
	return i;
}

int compare(char *s1,char *s2){
	int l1,l2,i,a,b;
	l1=length(s1);
	l2=length(s2);

	for(i=0;i<l1;i++)
	{

		if(*(s1+i)>*(s2+i))
		{
			return 1;
		}
		if(*(s1+i)<*(s2+i))
		{
			return 0;
		}
	}
	return 2;
}

void reverse(char *s,char *rev){
	int l,i,j;
	l=length(s);

	for(i=0,j=l-1;i<l,j>=0;i++,j--){
		*(rev+j)=*(s+i);

	}
	*(rev+l)='\0';
}

void copy(char *p,char *r)
{
	int i;
	for(i=0;(*(p+i))!='\0';i++)
	{
		(*(r+i))=(*(p+i));
	}
	(*(r+i))='\0';
}

int palindrome(char *p,char *r)
{
	int k;
	reverse(p,r);
	k=compare(p,r);
	return k;
}


int substring(char *s1,char *s2){
	int l1,l2,i,j,a,flag,count=0;
	char *temp1,*temp2;
	l1=length(s1);
	l2=length(s2);

	if(l1>l2){

	for(i=0;i<l1;i++)
	{
		if(*s1==*s2){
		temp1=s1;
		temp2=s2;
			for(j=0;j<l2;j++){

				if(*s1!=*s2){
					flag=1;
					break;
				}
				flag=0;
				s1++;
				s2++;
			}
			s1=temp1;
			s2=temp2;
			if(flag==0){
				count++;
			}

		}
	s1++;
	}
	}

	return count;
}





